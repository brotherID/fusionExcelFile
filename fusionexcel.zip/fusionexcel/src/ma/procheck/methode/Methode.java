package ma.procheck.methode;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Methode {
	
	public static Properties loadFileInit() {
		Properties configProp = new Properties();
		try {
			//InputStream is = this.getClass().getResourceAsStream("/config.properties");
			String settingsPropertyFile = System.getProperty("user.dir")+"/config.properties";
			FileReader fReader = new FileReader(settingsPropertyFile);
			
			configProp.load(fReader);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return configProp;
	}
}
