package ma.procheck;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ma.procheck.methode.Methode;

public class Fusion {
	public static final Logger LOGGER = Logger.getLogger(Fusion.class.getName());
	public static Integer nbTotalLigne=0;
	public static final Properties configProp=Methode.loadFileInit();
	
	public static void main(String[] args) {
		
		try {
			File fold = new File(System.getProperty("user.dir")+"/logs");
			fold.mkdir();
			PropertyConfigurator.configure("log4j.properties");
			String typeListe=configProp.getProperty("FusionFile.TypeListe");
			String output=configProp.getProperty("FusionFile.PathFileExcelOutput");
			File fileOutFile=new File(output);
			LOGGER.info( "Le programme est lanc�");
			File folder = new File(configProp.getProperty("FusionFile.PathSFileExcel"));
			List<File> fileNames =new ArrayList<File>();
			fileNames=listFilesForFolder(folder,fileNames);
			if(fileNames!=null) {
				List<String> nameSheet=new ArrayList<String>();
				if(typeListe.equals("Complets")) {
					nameSheet.add("Complets");
					nameSheet.add("Complets ");
					nameSheet.add("Complets-");
					nameSheet.add("les complets");
				}
				else {
					nameSheet.add("Incomplets");
					nameSheet.add("Incomplets ");
					nameSheet.add("Incomplets -");
					nameSheet.add("Incomplet");
				}
				
				Map<Integer, List<List<String>>> allExcelsData= getAllExcelsData(fileNames,nameSheet);
				if(!allExcelsData.isEmpty()) {
					LOGGER.info( "creation du fichier : "+configProp.getProperty("FusionFile.PathFileExcelOutput")+" ...");
					writefile(fileOutFile, allExcelsData,nameSheet.get(0));
				}
			}
			else {
				LOGGER.fatal("folder not found: ["+folder+"]");
			}
			LOGGER.info( "Le programme est termin�");
		} catch (SecurityException e) {
			LOGGER.fatal( "SecurityException:",e);
		}
		
		
	}
	
	/**
	 * g�n�re un fichier excel
	 * @param output : chemin sortie 
	 * @param allExcelsData : list des donnees des fichier excel
	 * @param nameSheet : nom feuil fichier excel
	 */
	public static void writefile(File output,Map<Integer, List<List<String>>> allExcelsData,String nameSheet) {
		
		BufferedWriter bw = null;
        FileWriter fw = null;
        
        try {

            fw = new FileWriter(output);
            bw = new BufferedWriter(fw);
            
            List<List<String>> excelsData=null;
    		Set<Integer> keyset = allExcelsData.keySet();
    		bw.write("Liste|"+nameSheet);
        	bw.newLine();
    		bw.write("Quantit�|"+nbTotalLigne);
        	bw.newLine();
        	bw.newLine();
        	bw.newLine();
        	int nbrColon=Integer.valueOf(configProp.getProperty("FusionFile.nbrColon"));
        	String line="";
        	for (int i = 1; i <= nbrColon; i++) {
        		line+=configProp.getProperty("FusionFile.colonne"+i)+"|";
			}
        	bw.write(line.substring(0, line.length()-1));
        	bw.newLine();
    		for (Integer key : keyset) { 
                // this creates a new row in the sheet 
                excelsData = allExcelsData.get(key);
                for (List<String> listData:excelsData) {
                	line="";
                	for(String data:listData) {
                		line+=data+"|";
                    }
                	bw.write(line.substring(0, line.length()-1));
                	bw.newLine();
                }
             }
        } catch (IOException e) {
        	LOGGER.fatal( "IOException",e);
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {
            	LOGGER.fatal( "IOException",ex);
            }
        }
	}
	
	/**
	 * r�cupere les fichiers excel dans le dossier et sous dossier
	 * @param folder : dossier d'entre
	 * @param fileNames : liste des fichiers excel
	 * @return
	 */
	public static List<File> listFilesForFolder(File folder,List<File> fileNames) {
		if(folder.listFiles()!=null) {
		    for (File fileEntry : folder.listFiles()) {
		        if (fileEntry.isDirectory()) {
		            listFilesForFolder(fileEntry,fileNames);
		        } else {
		        	if(fileEntry.getName().matches("(.*).xlsx|(.*).xls")) {
		        		fileNames.add(fileEntry);
		        	}
		        }
		    }
		    return fileNames;
		}
		else {
			return null;
		}
	    
	}
	
	/**
	 * fusionner les fichiers excel 
	 * @param input : dossier d'entre
	 * @param nameSheet : list feuil excel 
	 */
	public static void fusionExcel(String input,List<String> nameSheet) {
		
		File folder = new File(input);
		List<File> fileNames =new ArrayList<File>();
		fileNames=listFilesForFolder(folder,fileNames);
		Map<Integer, List<List<String>>> allExcelsData= getAllExcelsData(fileNames,nameSheet);
		
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		  
        // Create a blank sheet 
        XSSFSheet sheet = workbook.createSheet(nameSheet.get(0)); 
  
        // Iterate over data and write to sheet 
        Set<Integer> keyset = allExcelsData.keySet(); 
        int rownum = 0; 
        XSSFRow row = null;
        XSSFCell cell;
        XSSFCellStyle headerCellStyle1 = workbook.createCellStyle();
        headerCellStyle1.setBorderBottom(BorderStyle.THIN);
        headerCellStyle1.setBorderTop(BorderStyle.THIN);
        headerCellStyle1.setBorderRight(BorderStyle.THIN);
        headerCellStyle1.setBorderLeft(BorderStyle.THIN);
       
        List<List<String>> excelsData;
        for (Integer key : keyset) {
   
            // this creates a new row in the sheet 
            excelsData = allExcelsData.get(key);
            for (int i = 0; i < excelsData.size(); i++) {
            	row= sheet.createRow(rownum);
            	for(int j = 0; j < excelsData.get(i).size(); j++) {
            		cell = row.createCell(j);
                    cell.setCellValue(excelsData.get(i).get(j));
                    cell.setCellStyle(headerCellStyle1);
                }
            	rownum++;
			}  
        }
        try { 
            // this Writes the workbook
        	File direxcel = new File(configProp.getProperty("FusionFile.PathDesFileExcelOutput"));
			//direxcel.mkdir();
            FileOutputStream out = new FileOutputStream(new File(direxcel+"\\outputFile.xlsx")); 
            workbook.write(out); 
            out.close();
           //System.out.println(fileNames[0].getName()+" written successfully on disk.\n chemin file: "+direxcel) ; 
            workbook.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
 
	}
	
	/**
	 * test si un String is num�rique
	 * @param strNum
	 * @return
	 */
	public static  boolean isNumeric(String strNum) {
	    try {
	        Double.valueOf(strNum).intValue();
	    } catch (NumberFormatException e) {
	        return false;
	    }
	    return true;
	}
	
	/**
	 * r�cupere tout les donnees des fichiers excel 
	 * @param fileNames : list fichiers excel
	 * @param nameSheet : list feuil excel
	 * @return
	 */
	public static Map<Integer, List<List<String>>> getAllExcelsData(List<File> fileNames,List<String> nameSheet){
		Map<Integer, List<List<String>>> allExcelsData=new HashMap<Integer, List<List<String>>>();
		for (int i = 0; i < fileNames.size(); i++) {
			List<List<String>> excelData=getExcelData(fileNames.get(i), nameSheet);
			if(excelData!=null)
				allExcelsData.put(i, excelData);
		}
		return allExcelsData;	
	}
	
	/**
	 * r�cupere les donnees d'un fichier excel
	 * @param excelFilePath : chemin + name 
	 * @param excelSheetName: list feuil excel
	 * @return
	 */
	public static List<List<String>>  getExcelData(File excelFilePath, List<String> excelSheetName){
		
		List<List<String>> ret = new ArrayList<List<String>>();
		if(excelFilePath!=null && !"".equals(excelFilePath.toString().trim()) && excelSheetName!=null){
			try{
				/* Open the file input stream. */
				if(excelFilePath.exists()) {
					FileInputStream fis = new FileInputStream(excelFilePath.toString().trim());
					
					if(excelFilePath.toString().toLowerCase().endsWith(".xlsx")) {
						XSSFWorkbook excelWookBook = new XSSFWorkbook(fis);
						XSSFSheet copySheet = null;
						for (int i = 0; i < excelSheetName.size(); i++) {
							copySheet=excelWookBook.getSheet(excelSheetName.get(i));
							if(copySheet!=null)
								break;
						}
						boolean testValide=true;
						if(copySheet!=null) {
							int fRowNum =copySheet.getFirstRowNum();
							int lRowNum = copySheet.getLastRowNum();
							XSSFCell cellComp = null;
							for(int i=fRowNum; i<lRowNum+1; i++){
								XSSFRow row = copySheet.getRow(i);
								if(row!=null) {
									List<String> rowDataList = new ArrayList<String>();
									XSSFCell cell = null;
									int fCellNum = row.getFirstCellNum();
									int lCellNum = row.getLastCellNum();
									if(i>4 && lCellNum!=Integer.valueOf(configProp.getProperty("FusionFile.nbrColon"))) {
										continue;
									}
									for(int j = fCellNum; j < lCellNum; j++){
										cell=row.getCell(j);
										if(cell!=null) {
											if(row.getCell(0)==null || (row.getCell(0).toString().equals("") && i<4)) {
												break;
											}	
											if(row.getCell(0)==null || row.getCell(0).toString().equals("MDN")||row.getCell(1).toString().equals("MDN")) {
												if(row.getCell(0).toString().equals("MDN")||row.getCell(1).toString().equals("MDN")) {
													if(lCellNum!=Integer.valueOf(configProp.getProperty("FusionFile.nbrColon")))
														testValide=false;
												}
												break;
											}
											if(i==0) {
												if(row.getCell(1)==null || row.getCell(1).getCellTypeEnum()==CellType.NUMERIC) {
													cellComp=row.getCell(1);
												}
												break;
											}
											else if(i==1) {
												if(row.getCell(1)==null || row.getCell(1).getCellTypeEnum()==CellType.NUMERIC) {
													cellComp=row.getCell(1);
												}
												break;
											}
											if(cell.getCellTypeEnum()==CellType.NUMERIC) {
												if(!isNumeric(cell.toString())) {
													SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
													rowDataList.add(dt.format(cell.getDateCellValue()));
												}
												else {
													rowDataList.add(Double.valueOf(cell.toString()).intValue()+"");
												}
											}
											else {
												rowDataList.add(cell.toString());
											}
										}
									}
									List<String> rowList=new ArrayList<String>(rowDataList);
									for (int j = 0; j < rowList.size(); j++) {
										if(rowList.get(j).equals(" ")||rowList.get(j).equals("")) {
											rowList.remove(j);
											j=-1;
										}
									}
									if(!rowList.isEmpty()) {
										ret.add(rowDataList);
									}
								}
							}
							excelWookBook.close();
							int quantite=Double.valueOf(cellComp.toString()).intValue();
							if(!testValide) {
								LOGGER.error("nombre colonne # ["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][Quantit�:"+quantite+"]");
								//if(excelFilePath.exists()) {
									//Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								//}
								return null;
							}
							boolean testLigne=ret.size()==quantite;
							if(testLigne) {
								nbTotalLigne=nbTotalLigne+quantite;
								LOGGER.info("Read file: ["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][nombre ligne:"+ret.size()+"=Quantit�:"+quantite+"]");
								//Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelFini")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								return ret;
							}
							else {
								LOGGER.error("["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][nombre ligne:"+ret.size()+"#Quantit�:"+quantite+"]");
								//if(excelFilePath.exists()) {
									//Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								//}
								return null;
							}
						}
						else {
							excelWookBook.close();
							LOGGER.error(excelSheetName.get(0)+":"+excelFilePath.getName());
							//if(excelFilePath.exists()) {
								//Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
							//}
							return null;
						}
					}
					else {
						HSSFWorkbook excelWookBook = new HSSFWorkbook(fis);
						HSSFSheet copySheet = null;
						for (int i = 0; i < excelSheetName.size(); i++) {
							copySheet=excelWookBook.getSheet(excelSheetName.get(i));
							if(copySheet!=null)
								break ;
						}
						boolean testValide=true;
						if(copySheet!=null) {
							int fRowNum =copySheet.getFirstRowNum();
							int lRowNum = copySheet.getLastRowNum();
							HSSFCell cellComp = null;
							for(int i=fRowNum; i<lRowNum+1; i++){
								HSSFRow row = copySheet.getRow(i);
								if(row!=null) {
									List<String> rowDataList = new ArrayList<String>();
									HSSFCell cell = null;
									int fCellNum = row.getFirstCellNum();
									int lCellNum = row.getLastCellNum();
									if(i>4 && lCellNum!=Integer.valueOf(configProp.getProperty("FusionFile.nbrColon"))) {
										continue;
									}	
									for(int j = fCellNum; j < lCellNum; j++){
										cell=row.getCell(j);
										if(cell!=null) {
											if(row.getCell(0)==null || (row.getCell(0).toString().equals("") && i<4)) {
												break;
											}	
											if(row.getCell(0)==null || row.getCell(0).toString().equals("MDN")||row.getCell(1).toString().equals("MDN")) {
												if(row.getCell(0).toString().equals("MDN")||row.getCell(1).toString().equals("MDN")) {
													if(lCellNum!=Integer.valueOf(configProp.getProperty("FusionFile.nbrColon")))
														testValide=false;
												}	
												break;
											}
											if(i==0) {
												if(row.getCell(1)==null || row.getCell(1).getCellTypeEnum()==CellType.NUMERIC) {
													cellComp=row.getCell(1);
												}
												break;
											}
											else if(i==1) {
												if(row.getCell(1)==null || row.getCell(1).getCellTypeEnum()==CellType.NUMERIC) {
													cellComp=row.getCell(1);
												}
												break;
											}
											if(cell.getCellTypeEnum()==CellType.NUMERIC) {
												if(!isNumeric(cell.toString())) {
													SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
													rowDataList.add(dt.format(cell.getDateCellValue()));
												}
												else {
													rowDataList.add(Double.valueOf(cell.toString()).intValue()+"");
												}
											}
											else {
												rowDataList.add(cell.toString());
											}
										}
									}
									List<String> rowList=new ArrayList<String>(rowDataList);
									for (int j = 0; j < rowList.size(); j++) {
										if(rowList.get(j).equals(" ")||rowList.get(j).equals("")) {
											rowList.remove(j);
											j=-1;
										}
									}
									if(!rowList.isEmpty()) {
										ret.add(rowDataList);
									}
								}
							}
							excelWookBook.close();
							int quantite=Double.valueOf(cellComp.toString()).intValue();
							if(!testValide) {
								LOGGER.error("nombre colonne # ["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][Quantit�:"+quantite+"]");
								//if(excelFilePath.exists()) {
									////Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								//}
								return null;
							}
							boolean testLigne=ret.size()==quantite;
							if(testLigne) {
								nbTotalLigne=nbTotalLigne+quantite;
								LOGGER.info("Read file: ["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][nombre ligne:"+ret.size()+"=Quantit�:"+quantite+"]");
								////Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelFini")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								return ret;
							}
							else {
								LOGGER.error("["+excelFilePath.getName()+"][Sheet Name:"+excelSheetName.get(0)+"][nombre ligne:"+ret.size()+"#Quantit�:"+quantite+"]");
								//if(excelFilePath.exists()) {
									////Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
								//}
								return null;
							}
						}
						else {
							excelWookBook.close();
							LOGGER.error(excelSheetName.get(0)+":"+excelFilePath.getName());
							//if(excelFilePath.exists()) {
								////Files.move(Paths.get(excelFilePath.toString()),Paths.get(configProp.getProperty("FusionFile.PathDesFileExcelError")+"\\"+excelFilePath.getName()),StandardCopyOption.REPLACE_EXISTING);
							//}
							return null;
						}
					}
				}
			}catch(Exception ex){
				LOGGER.fatal( "ERROR:"+ex.getMessage(),ex);
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param input
	 * @param output
	 * @param dataMap
	 * @param nameS
	 * @return
	 */
	public static  String updateExcel(String input,String output,Map<Integer, List<List<String>>> dataMap,String nameS) {
		
		FileInputStream fis;
		try {
			
			File fileNames = new File(input);
			fis = new FileInputStream(fileNames);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			
			XSSFCellStyle headerCellStyle1 = workbook.createCellStyle();
	        headerCellStyle1.setBorderBottom(BorderStyle.THIN);
	        headerCellStyle1.setBorderTop(BorderStyle.THIN);
	        headerCellStyle1.setBorderRight(BorderStyle.THIN);
	        headerCellStyle1.setBorderLeft(BorderStyle.THIN);
			//for (int m = 0; m < workbook.getNumberOfSheets(); m++) {
			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row=null;
			XSSFCell cell=null;
			int rownum = 4;
			List<List<String>> excelsData=null;
			Set<Integer> keyset = dataMap.keySet(); 
			for (Integer key : keyset) { 
	            // this creates a new row in the sheet 
	            excelsData = dataMap.get(key);
	            for (List<String> listData:excelsData) {
	            	row= sheet.createRow(rownum);
	            	int j=0;
	            	for(String data:listData) {
	            		cell = row.createCell(j);
	            		cell.setCellValue(data);
	                    cell.setCellStyle(headerCellStyle1);
	                    cell=null;
	                    System.gc();
	                    j++;
	            	}
	            	row=null;
	            	System.gc();
	            	rownum++;
				}
	            excelsData=null;
	            System.gc();
	            
	        }
			row= sheet.getRow(0);
			cell = row.createCell(1);
			cell.setCellValue(nameS);
			cell.setCellStyle(headerCellStyle1);
			
			row= sheet.getRow(1);
			cell = row.createCell(1);
			cell.setCellValue(nbTotalLigne);
			cell.setCellStyle(headerCellStyle1);
			
			workbook.setSheetName(0, nameS);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			evaluator.evaluateAll();
				
			fis.close();
			FileOutputStream fos =new FileOutputStream(new File(output));
			
			workbook.write(fos);
		    workbook.close();
		    fos.close();
				
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			return e.getMessage();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;	
	}
	
}
