package dev.procheck.fusionexcel;

import dev.procheck.fusionexcel.CommonFunc;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PKFusion {
	public static boolean writefile(File output, Map<Integer, List<List<String>>> allExcelsData) {
		boolean isOk = false;
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			if (allExcelsData != null) {
				fw = new FileWriter(output);
				bw = new BufferedWriter(fw);
				List<List<String>> excelsData = null;
				Set<Integer> keyset = allExcelsData.keySet();
				String line = "";
				for (Integer key : keyset) {
					excelsData = allExcelsData.get(key);
					for (List<String> listData : excelsData) {
						line = "";
						for (String data : listData) {
							if (CommonFunc.isNumeric(data)) {
								line = String.valueOf(line) + "\t" + data + ";";
								continue;
							}
							line = String.valueOf(line) + data + ";";
						}
						bw.write(line.substring(0, line.length() - 1));
						bw.newLine();
					}
				}
				isOk = true;
				PKMain.LOGGER.info("[le fichier : " + output.getName() + " est cr�e");
			} else {
				PKMain.LOGGER.info("[le fichier : " + output.getName() + " n'est pas cr�e");
			}
		} catch (IOException e) {
			PKMain.LOGGER.error("IOException", e);
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				PKMain.LOGGER.error("IOException", ex);
			}
		}
		return isOk;
	}

	public static Map<Integer, List<List<String>>> getAllExcelsData(File[] fileNames) {
		Map<Integer, List<List<String>>> allExcelsData = new HashMap<>();
		for (int i = 0; i < fileNames.length; i++) {
			List<List<String>> excelData = getExcelData(fileNames[i], i);
			if (excelData != null) {
				PKMain.LOGGER.info("[" + fileNames[i] + "][fichier traiter]");
				allExcelsData.put(Integer.valueOf(i), excelData);
			} else {
				PKMain.LOGGER.warn("[" + fileNames[i] + "][fichier non traiter]");
			}
		}
		if (allExcelsData.size() == 0)
			return null;
		return allExcelsData;
	}

	@SuppressWarnings("deprecation")
	public static List<List<String>> getExcelData(File excelFilePath, int k) {
		List<List<String>> ret = new ArrayList<>();
		if (excelFilePath != null && !"".equals(excelFilePath.toString().trim()))
			try {
				if (excelFilePath.exists()) {
					FileInputStream fis = new FileInputStream(excelFilePath.toString().trim());
					if (excelFilePath.toString().toLowerCase().endsWith(".xlsx")) {
						XSSFWorkbook excelWookBook = new XSSFWorkbook(fis);
						XSSFSheet copySheet = null;
						int totalSheets = excelWookBook.getNumberOfSheets();
						for (int t = 0; t < totalSheets; t++) {
							copySheet = excelWookBook.getSheetAt(t);
							if (copySheet != null) {
								int fRowNum = copySheet.getFirstRowNum() + 1;
								if (k == 0)
									fRowNum = copySheet.getFirstRowNum();
								int lRowNum = copySheet.getLastRowNum();
								for (int i = fRowNum; i < lRowNum + 1; i++) {
									XSSFRow row = copySheet.getRow(i);
									if (row != null) {
										List<String> rowDataList = new ArrayList<>();
										XSSFCell cell = null;
										int fCellNum = row.getFirstCellNum();
										int lCellNum = row.getLastCellNum();
										for (int j = fCellNum; j < lCellNum; j++) {
											cell = row.getCell(j);
											if (cell != null) {
												if (cell.getCellTypeEnum() == CellType.NUMERIC) {
													rowDataList.add((new StringBuilder(
															String.valueOf(Double.valueOf(cell.toString()).intValue())))
																	.toString());
												} else {
													rowDataList.add(cell.toString());
												}
											} else {
												rowDataList.add("");
											}
										}
										List<String> rowList = new ArrayList<>(rowDataList);
										for (int m = 0; m < rowList.size(); m++) {
											if (((String) rowList.get(m)).equals(" ")
													|| ((String) rowList.get(m)).equals("")) {
												rowList.remove(m);
												m = -1;
											}
										}
										if (!rowList.isEmpty())
											ret.add(rowDataList);
									}
								}

							} else {
								excelWookBook.close();
								PKMain.LOGGER.error("pas de feuille dans le fichier");
								return null;
							}
							
						} // fin for
						excelWookBook.close();
					} else {
						HSSFWorkbook excelWookBook = new HSSFWorkbook(fis);
						HSSFSheet copySheet = null;
						copySheet = excelWookBook.getSheetAt(0);
						if (copySheet != null) {
							int fRowNum = copySheet.getFirstRowNum() + 1;
							if (k == 0)
								fRowNum = copySheet.getFirstRowNum();
							int lRowNum = copySheet.getLastRowNum();
							for (int i = fRowNum; i < lRowNum + 1; i++) {
								HSSFRow row = copySheet.getRow(i);
								if (row != null) {
									List<String> rowDataList = new ArrayList<>();
									HSSFCell cell = null;
									int fCellNum = row.getFirstCellNum();
									int lCellNum = row.getLastCellNum();
									for (int j = fCellNum; j < lCellNum; j++) {
										cell = row.getCell(j);
										if (cell != null)
											if (cell.getCellTypeEnum() == CellType.NUMERIC) {
												rowDataList.add((new StringBuilder(
														String.valueOf(Double.valueOf(cell.toString()).intValue())))
																.toString());
											} else {
												rowDataList.add(cell.toString());
											}
									}
									List<String> rowList = new ArrayList<>(rowDataList);
									for (int m = 0; m < rowList.size(); m++) {
										if (((String) rowList.get(m)).equals(" ")
												|| ((String) rowList.get(m)).equals("")) {
											rowList.remove(m);
											m = -1;
										}
									}
									if (!rowList.isEmpty())
										ret.add(rowDataList);
								}
							}
							excelWookBook.close();
						} else {
							excelWookBook.close();
							PKMain.LOGGER.error("pas de feuille dans le fichier");
							return null;
						}
					}
				}
			} catch (Exception ex) {
				PKMain.LOGGER.error("error file", ex);
				return null;
			}
		return ret;
	}
}
