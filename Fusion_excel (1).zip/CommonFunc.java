package dev.procheck.fusionexcel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
public class CommonFunc {

	public static Properties loadFileInit() {
	    Properties configProp = new Properties();
	    try {
	      String settingsPropertyFile = String.valueOf(System.getProperty("user.dir")) + "/config/config.properties";
	      FileReader fReader = new FileReader(settingsPropertyFile);
	      configProp.load(fReader);
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    } 
	    return configProp;
	  }
	  
	  public static boolean isNumeric(String strNum) {
	    try {
	      Double.valueOf(strNum).intValue();
	    } catch (NumberFormatException e) {
	      return false;
	    } 
	    return true;
	  }
	  
	  public static List<File> listFilesForFolder(File folder, List<File> fileNames) {
	    if (folder.listFiles() != null) {
	      byte b;
	      int i;
	      File[] arrayOfFile;
	      for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
	        File fileEntry = arrayOfFile[b];
	        if (fileEntry.isDirectory()) {
	          listFilesForFolder(fileEntry, fileNames);
	        } else if (fileEntry.getName().matches("(.*).xlsx|(.*).xls")) {
	          fileNames.add(fileEntry);
	        } 
	        b++;
	      } 
	      return fileNames;
	    } 
	    return null;
	  }
}
