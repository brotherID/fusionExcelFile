package dev.procheck.fusionexcel;

import java.io.File;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class PKMain {

	public static final Logger LOGGER = Logger.getLogger(PKFusion.class.getName());
	  
	  public static final Properties configProp = CommonFunc.loadFileInit();
	  
	  public static void main(String[] args) {
	    try {
	      File fold = new File(String.valueOf(System.getProperty("user.dir")) + "/logs");
	      fold.mkdir();
	      PropertyConfigurator.configure("D:\\bureau\\fusion excel/config/log4j.properties");
	      String output = configProp.getProperty("D:\\bureau\\fusion excel");
	      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmssSSS");
	      String fileNameOutput = "resultat_" + dateFormat.format(new Date()) + ".csv";
	      File fileOutFile = new File(String.valueOf(output) + "\\" + fileNameOutput);
	      LOGGER.info("[Le programme est lanc�e");
	      File folder = new File(configProp.getProperty("D:\\bureau\\fusion excel"));
	      File[] fileNames = folder.listFiles(new FilenameFilter() {
	            public boolean accept(File folder, String name) {
	              return name.matches("(.*).xlsx|(.*).xls");
	            }
	          });
	      if (fileNames != null && fileNames.length != 0) {
	        Map<Integer, List<List<String>>> allExcelsData = PKFusion.getAllExcelsData(fileNames);
	        if (allExcelsData != null && !allExcelsData.isEmpty()) {
	          LOGGER.info("[creation du fichier : " + fileOutFile + "]");
	          PKFusion.writefile(fileOutFile, allExcelsData);
	        } 
	      } else if (fileNames != null && fileNames.length == 0) {
	        LOGGER.error("[no file in folder][" + folder + "]");
	      } else {
	        LOGGER.error("[folder not found][" + folder + "]");
	      } 
	      LOGGER.info("[Le programme est termin\n--------------------------------------------------------------------");
	    } catch (SecurityException e) {
	      LOGGER.error("SecurityException:", e);
	    } 
	  }
	  
}
